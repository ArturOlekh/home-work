public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println();
        System.out.println("Домашнее задание №1");
        System.out.println();
        char dot = 'G';
        System.out.println(dot);
        int number11 = 89;
        System.out.println(number11);
        byte number = 4;
        System.out.println(number);
        short number1 = 56;
        System.out.println(number1);
        float number2 = 4.7333436f;
        System.out.println(number2);
        double number3 = 4.355453532;
        System.out.println(number3);
        long number4 = 12121L;
        System.out.println(number4);
        System.out.println();
        System.out.println("Домашнее задание №2");
        System.out.println();
        int i = 345;
        System.out.print(i + " -> ");
        System.out.print(i / 100 + ", ");
        System.out.print(i / 10 % 10 + ", ");
        System.out.print(i % 10 + ". ");
        System.out.println();
        System.out.println("Дополнительное задание1");
        System.out.println();
        int number5 = 1234567890;
        int  number6 = 1;
        System.out.println(number5);
        int  Sum = number5 + number6;
        System.out.println(Sum);
        System.out.println();
        System.out.println("Дополнительное задание2");
        System.out.println();
        int number7 = 15;
        double number8 = 15.1;
        double Sum1 = number7 * number8;// В сумме мне тип данних int или double нужно ввести имеет
        // значение?? Спасибо
        System.out.println(Sum1);
        System.out.println();
        System.out.println("Дополнительное задание3");
        System.out.println();
        char letter = 'A';
        System.out.println(letter);
        int number9 = 1;
        char Sum2 = 'A' + 1;
        System.out.println(Sum2);










    }
}