public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println();
        System.out.println("Домашнее задание №1");
        System.out.println();
        char dot = 'G';
        System.out.println(dot);
        int number = 89;
        System.out.println(number);
        byte число = 4;
        System.out.println(число);
        short папугаи = 56;
        System.out.println(папугаи);
        float дробное = 4.7333436f;
        System.out.println(дробное);
        double дробное1 = 4.355453532;
        System.out.println(дробное1);
        long длинное = 12121l;
        System.out.println(длинное);
        System.out.println();
        System.out.println("Домашнее задание №2");
        System.out.println();
        System.out.println("Число 345 -> 3,4,5");
        System.out.println();
        System.out.println("Дополнительное задание1");
        System.out.println();
        int удав = 1234567890;
        int  какаду = 1;
        System.out.println(удав);
        int  сумма = удав + какаду;
        System.out.println(сумма);
        System.out.println();
        System.out.println("Дополнительное задание2");
        System.out.println();
        int целое = 15;
        double дробное2 = 15.1;
        double сумма1 = целое * дробное;// В сумме мне тип данних int или double нужно ввести имеет
        // значение?? Спасибо
        System.out.println(сумма1);
        System.out.println();
        System.out.println("Дополнительное задание3");
        System.out.println();
        char буква = 'A';
        System.out.println(буква);
        int число1 = 1;
        char сумма2 = 'A' + 1;
        System.out.println(сумма2);










    }
}